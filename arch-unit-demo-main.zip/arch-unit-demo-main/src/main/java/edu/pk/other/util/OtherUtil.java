package edu.pk.other.util;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 11:57 pm
 */
public class OtherUtil {

}
