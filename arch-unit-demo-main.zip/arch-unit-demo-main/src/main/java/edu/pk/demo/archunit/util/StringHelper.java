package edu.pk.demo.archunit.util;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 9:26 pm
 */
public class StringHelper {

  /**
   * Helper method to check null or empty.
   * @param str to check
   * @return true if empty
   */
  public static boolean isNullOrEmpty(String str) {
    return str == null || str.isEmpty();
  }
}
