package edu.pk.demo.archunit.core;

import edu.pk.demo.archunit.helper.JunoHelper;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class CacheDataProvider extends DataProvider<String> {
	
	/**
	 * This method provides data of type T for a given filter set.
	 *
	 * @param filters filter set
	 * @return required data of type T
	 */
	@Override
	public List<String> getByFilter(Map<String, Object> filters) {
		final JunoHelper junoHelper = new JunoHelper();
		return Collections.singletonList(junoHelper.get("key"));
	}
}
