package edu.pk.demo.archunit.api;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 8:50 pm To change this template use File | Settings | File and Code Templates.
 */
public interface CampaignManagement {
	
	/**
	 * Get campaign by campaignId
	 * @return campaign
	 */
	String getById(String id);
}
