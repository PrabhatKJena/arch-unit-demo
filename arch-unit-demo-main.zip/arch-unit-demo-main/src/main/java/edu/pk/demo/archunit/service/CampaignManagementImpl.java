package edu.pk.demo.archunit.service;

import edu.pk.demo.archunit.api.CampaignManagement;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 8:50 pm To change this template use File | Settings | File and Code Templates.
 */
public class CampaignManagementImpl implements CampaignManagement {
	
	/**
	 * Get campaign by campaignId
	 *
	 * @return campaign
	 */
	@Override
	public String getById(String id) {
		return "";
	}
}
