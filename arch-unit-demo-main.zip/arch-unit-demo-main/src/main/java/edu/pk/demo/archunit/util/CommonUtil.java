package edu.pk.demo.archunit.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * This is a utility class holds all common logic for utility tasks.
 */
public class CommonUtil {

  public static Integer getRandomInteger(int min, int max) {
    Random random = new Random();
    return random.nextInt((max - min) + 1) + min;
  }

  /**
   * This method return current time for given format.
   *
   * @return formatted time
   */
  public static String currentTime() {
    String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
    return sdf.format(new Date());
  }

  /**
   * This method multiplies 2 2-d array.
   *
   * @param a array 1
   * @param b array 2
   * @return result array
   */
  public static double[][] multiply(double[][] a, double[][] b) {
    double[][] result = new double[a.length][b[0].length];
    double[][] result1 = new double[a.length][b[0].length];
    for (int i = 0; i < a.length; i++) {
      for (int j = 0; j < b[0].length; j++) {
        double sum = 0;
        for (int k = 0; k < a[0].length; k++) {
          sum += a[i][k] * b[k][j];
        }
        result[i][j] = sum;
      }
    }
    // Duplicate for demo purpose only
    for (int i = 0; i < a.length; i++) {
      for (int j = 0; j < b[0].length; j++) {
        double sum = 0;
        for (int k = 0; k < a[0].length; k++) {
          sum += a[i][k] * b[k][j];
        }
        result1[i][j] = sum;
      }
    }
    return result;
  }
}
