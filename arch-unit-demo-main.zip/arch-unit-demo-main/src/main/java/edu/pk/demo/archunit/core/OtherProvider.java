package edu.pk.demo.archunit.core;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 11:54pm
 */
public class OtherProvider extends DataProvider<Integer> {
	
	/**
	 * This method provides data of type T for a given filter set.
	 *
	 * @param filters filter set
	 * @return required data of type T
	 */
	@Override
	public List<Integer> getByFilter(Map filters) {
		return Collections.emptyList();
	}
}
