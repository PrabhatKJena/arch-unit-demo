package edu.pk.demo.archunit.service;

import edu.pk.demo.archunit.api.CampaignManagement;

import java.util.Properties;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 8:51pm.
 */
public class CampaignManagementImplV2 implements CampaignManagement {
	
	private Properties properties;
	
	@Override
	public String getById(String id) {
		return "";
	}
	
	public Properties getProperties() {
		return properties;
	}
	
	public void setProperties(Properties properties) {
		this.properties = properties;
	}
}
