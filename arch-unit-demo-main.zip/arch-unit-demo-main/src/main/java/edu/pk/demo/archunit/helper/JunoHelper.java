package edu.pk.demo.archunit.helper;

/**
 * Created by IntelliJ IDEA.
 * User: prajena
 * Date: 31/07/24
 * Time: 1:30pm
 */
public class JunoHelper {
	
	public String get(String key) {
		return key + ":dummy";
	}
}
