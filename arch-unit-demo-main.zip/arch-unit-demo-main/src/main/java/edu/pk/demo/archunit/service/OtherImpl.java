package edu.pk.demo.archunit.service;

import edu.pk.demo.archunit.api.CampaignManagement;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 8:53 pm
 */
public class OtherImpl implements CampaignManagement {
	
	/**
	 * Get campaign by campaignId
	 *
	 * @return campaign
	 */
	@Override
	public String getById(String id) {
		return "";
	}
}
