package edu.pk.demo.archunit.core;

import java.util.List;
import java.util.Map;

/**
 * This is an abstraction of provider class responsible to provide corresponding data.
 * All subclass must implement {@link #getByFilter(Map)} method to provide corresponding data.
 */
public abstract class DataProvider<T> {

  /**
   * This method provides data of type T for a given filter set.
   *
   * @param filters filter set
   * @return required data of type T
   */
  public abstract List<T> getByFilter(Map<String, Object> filters);
}
