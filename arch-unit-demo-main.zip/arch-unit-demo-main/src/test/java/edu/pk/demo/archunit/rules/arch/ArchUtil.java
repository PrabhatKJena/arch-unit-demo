package edu.pk.demo.archunit.rules.arch;

import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.resolution.declarations.ResolvedTypeDeclaration;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.domain.JavaMethod;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Created by IntelliJ IDEA.
 * User: prajena
 * Date: 31/07/24
 * Time: 12:37pm
 */
public class ArchUtil {
	
	private static final CombinedTypeSolver combinedTypeSolver = new CombinedTypeSolver();
	
	static {
		combinedTypeSolver.add(new ReflectionTypeSolver(false));
	}
	
	public static class JavaDocForMethodPredicate implements Predicate<MethodDeclaration> {
		final JavaClass javaClass;
		final Set<String> possibleSettersGettersByFields;
		
		public JavaDocForMethodPredicate(JavaClass javaClass) {
			this.javaClass = javaClass;
			possibleSettersGettersByFields = possibleSettersGettersByFields(javaClass);
		}
		
		@Override
		public boolean test(MethodDeclaration methodDeclaration) {
			/*Optional<ClassOrInterfaceDeclaration> parentInterface = findTopLevelInterface(methodDeclaration);
			if (parentInterface.isPresent()) {
				System.out.println("--------++++++++" + parentInterface.get().getName());
				Optional<MethodDeclaration> interfaceMethod = parentInterface.get().getMethods().stream()
						                                              .filter(im -> im.getNameAsString().equals(methodDeclaration.getNameAsString()))
						                                              .findFirst();
				return !(interfaceMethod.isPresent() && interfaceMethod.get().hasJavaDocComment());
			}*/
			return !possibleSettersGettersByFields.contains(methodDeclaration.getName().asString());
		}
	}
	
	public static String getFilePath(JavaClass javaClass) {
		String packagePath = javaClass.getPackageName().replace('.', '/');
		String className = javaClass.getSimpleName() + ".java";
		return RuleConstants.SRC_BASE_PATH + "/" + packagePath + "/" + className;
	}
	
	public static String getFilePath(JavaMethod javaMethod) {
		return getFilePath(javaMethod.getOwner());
	}
	
	public static Set<String> possibleSettersGettersByFields(JavaClass javaClass) {
		final Set<String> result = new HashSet<>();
		javaClass.getAllFields().stream()
				.map(javaField -> new StringBuilder(javaField.getName()))
				.forEach(name -> {
					name.setCharAt(0, Character.toUpperCase(name.charAt(0)));
					result.add("set" + name);
					result.add("get" + name);
				});
		return result;
	}
	
	/*public static Optional<ClassOrInterfaceDeclaration> findTopLevelInterface(MethodDeclaration method) {
		final Optional<ClassOrInterfaceDeclaration> classOrInterfaceDeclaration = method.findAncestor(ClassOrInterfaceDeclaration.class)
				                                                                          .filter(ClassOrInterfaceDeclaration::isInterface);
		if (!classOrInterfaceDeclaration.isPresent()) {
			return Optional.empty();
		}
		if (classOrInterfaceDeclaration.get().isInterface()) {
			return classOrInterfaceDeclaration;
		} else {
			return findTopLevelInterface(classOrInterfaceDeclaration.get().findAncestor())
		}
	}*/
	
	public static String getPackageNameFromExpression(Expression expr) {
		return JavaParserFacade.get(combinedTypeSolver)
				       .getType(expr)
				       .asReferenceType()
				       .getTypeDeclaration()
				       .map(ResolvedTypeDeclaration::getPackageName)
				       .orElse(null);
	}
}
