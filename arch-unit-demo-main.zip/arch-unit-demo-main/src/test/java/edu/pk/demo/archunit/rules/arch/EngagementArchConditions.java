package edu.pk.demo.archunit.rules.arch;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.domain.JavaType;
import com.tngtech.archunit.lang.ArchCondition;
import com.tngtech.archunit.lang.ConditionEvents;
import com.tngtech.archunit.lang.SimpleConditionEvent;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static edu.pk.demo.archunit.rules.arch.RuleConstants.CLASS_SUFFIX_IMPL;
import static edu.pk.demo.archunit.rules.arch.RuleConstants.MAX_METHOD_LINE_COUNT;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 9:43pm
 */
public class EngagementArchConditions {
	
	public static final ArchCondition<JavaClass> classNameEndsWithInterfaceNameWithImplSuffix =
			new ArchCondition<JavaClass>("have name ending with interface name with Impl as suffix") {
				private static final String messageFormat = "Class name %s implementing interface %s does not end with %sImpl";
				
				@Override
				public void check(JavaClass item, ConditionEvents events) {
					final List<JavaType> interfaces = new ArrayList<>(item.getInterfaces());
					final String interfaceName = ((JavaClass) interfaces.get(0)).getSimpleName();
					if (!item.getSimpleName().contains(interfaceName + CLASS_SUFFIX_IMPL)) {
						String message = String.format(messageFormat, item.getName(), interfaceName, interfaceName);
						events.add(SimpleConditionEvent.violated(item, message));
					}
				}
			};
	
	public static final ArchCondition<JavaClass> childClassNameMustHaveParentClassNameAsSuffix =
			new ArchCondition<JavaClass>("have name with parent class name as suffix") {
				private static final String messageFormat = "Class name %s does not have %s as suffix";
				
				@Override
				public void check(JavaClass item, ConditionEvents events) {
					if (!item.isInterface()) {
						if (item.getRawSuperclass().map(javaClass -> !javaClass.isInterface() && !javaClass.getName().equals(Object.class.getName())).orElse(false)) {
							final String superClassName = item.getRawSuperclass().map(JavaClass::getSimpleName).orElse(null);
							if (superClassName != null && !item.getSimpleName().endsWith(superClassName)) {
								String message = String.format(messageFormat, item.getName(), superClassName);
								events.add(SimpleConditionEvent.violated(item, message));
							}
						}
					}
				}
			};
	
	public static final ArchCondition<JavaClass> methodHavingStringLiteral =
			new ArchCondition<JavaClass>("not have methods with local variable with string literal as value") {
				private final String messageFormat = "Method \"%s\" in class %s contains a string literal '%s'.";
				
				@Override
				public void check(JavaClass javaClass, ConditionEvents events) {
					String filePath = ArchUtil.getFilePath(javaClass);
					try {
						String code = new String(Files.readAllBytes(Paths.get(filePath)));
						final ParseResult<CompilationUnit> parse = new JavaParser().parse(code);
						if (parse.isSuccessful() && parse.getResult().isPresent()) {
							final CompilationUnit cu = parse.getResult().get();
							cu.findAll(MethodDeclaration.class).forEach(method -> {
								method.findAll(StringLiteralExpr.class).forEach(stringLiteral -> {
									String literalValue = stringLiteral.asString();
									if (!stringLiteral.getValue().isEmpty()) {
										String message = String.format(messageFormat, method.getDeclarationAsString(), javaClass.getName(), literalValue);
										events.add(SimpleConditionEvent.violated(javaClass, message));
									}
								});
							});
						}
					} catch (IOException e) {
						System.out.println(e.toString());
					}
				}
			};
	
	public static final ArchCondition<JavaClass> methodMustNotHaveMoreThanNLines =
			new ArchCondition<JavaClass>("not have methods with more than 20 lines of code") {
				private final String messageFormat = "Method \"%s\" in class %s contains more than %d line of code.";
				
				@Override
				public void check(JavaClass javaClass, ConditionEvents events) {
					String filePath = ArchUtil.getFilePath(javaClass);
					try {
						String code = new String(Files.readAllBytes(Paths.get(filePath)));
						final ParseResult<CompilationUnit> parse = new JavaParser().parse(code);
						if (parse.isSuccessful() && parse.getResult().isPresent()) {
							final CompilationUnit cu = parse.getResult().get();
							cu.findAll(MethodDeclaration.class).forEach(method -> {
								if (method.getRange().isPresent()) {
									final int lineCount = method.getRange().get().getLineCount();
									if (lineCount > MAX_METHOD_LINE_COUNT) {
										String message = String.format(messageFormat, method.getDeclarationAsString(), javaClass.getName(), MAX_METHOD_LINE_COUNT);
										events.add(SimpleConditionEvent.violated(javaClass, message));
									}
								}
							});
						}
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				}
			};
	
	public static final ArchCondition<JavaClass> packageNamesShouldFollowConvention =
			new ArchCondition<JavaClass>("follow package naming convention") {
				@Override
				public void check(JavaClass javaClass, ConditionEvents events) {
					String packageName = javaClass.getPackageName();
					boolean matchesConvention = packageName.matches(RuleConstants.PACKAGE_NAME_PATTERN);
					
					if (!matchesConvention) {
						String message = String.format("Class %s is in package %s, which does not follow the naming convention %s",
								javaClass.getName(), packageName, RuleConstants.PACKAGE_NAME_PATTERN.replaceAll("\\\\", ""));
						events.add(SimpleConditionEvent.violated(javaClass, message));
					}
				}
			};
	
	
	public static final ArchCondition<JavaClass> publicMethodMustHaveJavaDoc =
			new ArchCondition<JavaClass>("have JavaDoc comment") {
				private static final String messageFormat = "Method %s in class %s does not have JavaDoc comment";
				@Override
				public void check(JavaClass klass, ConditionEvents events) {
					final ArchUtil.JavaDocForMethodPredicate methodPredicate = new ArchUtil.JavaDocForMethodPredicate(klass);
					final String filePath = ArchUtil.getFilePath(klass);
					try {
						String code = new String(Files.readAllBytes(Paths.get(filePath)));
						final ParseResult<CompilationUnit> parse = new JavaParser().parse(code);
						if (parse.isSuccessful() && parse.getResult().isPresent()) {
							final CompilationUnit cu = parse.getResult().get();
							cu.findAll(MethodDeclaration.class).forEach(methodDeclaration -> {
								if (methodPredicate.test(methodDeclaration) && !methodDeclaration.getJavadoc().isPresent()) {
									String message = String.format(messageFormat, methodDeclaration.getDeclarationAsString(), klass.getName());
									events.add(SimpleConditionEvent.violated(methodDeclaration, message));
								}
							});
						}
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				}
			};
	
	public static final ArchCondition<JavaClass> classShouldHaveJavaDoc =
			new ArchCondition<JavaClass>("have JavaDoc") {
				public static final String messageFormat = "class %s does not have JavaDoc comment";
				
				@Override
				public void check(JavaClass klass, ConditionEvents events) {
					final String filePath = ArchUtil.getFilePath(klass);
					try {
						String code = new String(Files.readAllBytes(Paths.get(filePath)));
						final ParseResult<CompilationUnit> parse = new JavaParser().parse(code);
						if (parse.isSuccessful() && parse.getResult().isPresent()) {
							final CompilationUnit cu = parse.getResult().get();
							cu.getTypes().stream().filter(BodyDeclaration::isClassOrInterfaceDeclaration).forEach(typeDeclaration -> {
								if (!typeDeclaration.getComment().isPresent()) {
									String message = String.format(messageFormat, klass.getName());
									events.add(SimpleConditionEvent.violated(klass, message));
								}
							});
						}
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				}
			};
	
	public static final ArchCondition<JavaClass> methodHavingObjectCreationWithNewKeyword =
			new ArchCondition<JavaClass>("not create object with \"new\" keyword") {
				public static final String messageFormat = "method %s in class %s created object with \"new\" keyword like: %s";
				
				@Override
				public void check(JavaClass klass, ConditionEvents events) {
					final String filePath = ArchUtil.getFilePath(klass);
					try {
						String code = new String(Files.readAllBytes(Paths.get(filePath)));
						final ParseResult<CompilationUnit> parse = new JavaParser().parse(code);
						if (parse.isSuccessful() && parse.getResult().isPresent()) {
							final CompilationUnit cu = parse.getResult().get();
							cu.findAll(MethodDeclaration.class).forEach(method -> {
								method.findAll(ObjectCreationExpr.class).stream().filter(this::isApplicationPackage)
										.forEach(objectCreationExpr -> {
											String message = String.format(messageFormat, method.getDeclarationAsString(), klass.getName(), objectCreationExpr.toString());
											events.add(SimpleConditionEvent.violated(klass, message));
										});
							});
						}
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				}
				
				private boolean isApplicationPackage(ObjectCreationExpr objectCreationExpr) {
					final String packageNameFromExpression = ArchUtil.getPackageNameFromExpression(objectCreationExpr);
					return packageNameFromExpression != null && packageNameFromExpression.contains(RuleConstants.PACKAGE_NAME_PREFIX);
				}
			};
}



