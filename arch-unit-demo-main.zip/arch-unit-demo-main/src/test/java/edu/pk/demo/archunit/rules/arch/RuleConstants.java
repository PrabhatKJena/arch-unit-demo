package edu.pk.demo.archunit.rules.arch;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 31/07/24 Time: 12:03 am
 */
public class RuleConstants {
	
	public final static String CLASS_SUFFIX_UTIL = "Util";
	public final static String CLASS_SUFFIX_IMPL = "Impl";
	public final static String CLASS_SUFFIX_CONSTANT = "Constants";
	public final static String PKG_ENDING_WITH_UTIL = "..util";
	
	public static final String SRC_BASE_PATH = "src/main/java";
	public static final String PACKAGE_NAME_PATTERN = "edu.pk.demo.archunit.*";
	public static final String PACKAGE_NAME_PREFIX = "edu.pk.demo.archunit";
	
	public static final int MAX_METHOD_LINE_COUNT = 20;
}
