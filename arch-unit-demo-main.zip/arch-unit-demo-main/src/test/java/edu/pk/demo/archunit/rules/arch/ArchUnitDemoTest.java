package edu.pk.demo.archunit.rules.arch;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption.Predefined;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 11:51m
 */
public class ArchUnitDemoTest {
	
	/**
	 * Use cases
	 * 1. Class must have interface as name with Impl as suffix when implementing single interface. √
	 *      Ex: classes CampaignManagementImpl, CampaignManagementImplV2 when implements CampaignManagement.
	 * 2. Class must have parent class name as suffix while extending. √
	 *      Ex: class CacheDataProvider when extends DataProvider
	 * 3. No string literals inside a method, always have static final class member. √
	 *      Ex: String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	 * 4. All public method must have Java doc defined. √
	 * 5. A method must not have more than N lines. (N can be tweaked with config) √
	 * 6. Classes must have Java doc defined. √
	 * 7. Package Naming Conventions like edu.pk.demo.archunit.controller.* √
	 * 8. Method should not create object locally using "new" keyword. √
	 *      Ex: final JunoHelper junoHelper = new JunoHelper();
	 */
	
	private static JavaClasses utilClasses;
	private static JavaClasses allClasses;
	
	@BeforeAll
	static void setup() {
		utilClasses = new ClassFileImporter()
				              .withImportOption(Predefined.DO_NOT_INCLUDE_TESTS)
				              .importPackages("edu.pk.demo.archunit.util");
		allClasses = new ClassFileImporter()
				             .withImportOption(Predefined.DO_NOT_INCLUDE_TESTS)
				             .importPackages("edu.pk");
	}
	
	@Test
	@DisplayName("Util classes should have proper naming convention")
	void utilClassNamingTest() {
		classes()
				.that()
				.resideInAnyPackage(RuleConstants.PKG_ENDING_WITH_UTIL)
				.should()
				.haveSimpleNameEndingWith(RuleConstants.CLASS_SUFFIX_UTIL)
				.because("All util classes must follow naming standard to have 'Util' as suffix.")
				.check(utilClasses);
	}
	
	@Test
	@DisplayName("Child class must have parent class name as suffix while extending.")
	void childClassNamingTest() {
		classes()
				.should(EngagementArchConditions.childClassNameMustHaveParentClassNameAsSuffix)
				.because("it makes class identification easier")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Method must not contain more than 20 lines. ")
	void methodLineCountTest() {
		classes()
				.should(EngagementArchConditions.methodMustNotHaveMoreThanNLines)
				.because("lengthy methods are not readable")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Class must not contain local variables with string literal as value.")
	void methodHavingStringLiteralTest() {
		classes()
				.should(EngagementArchConditions.methodHavingStringLiteral)
				.because("String literals should be defined in a centralized constants class")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Class implementing single interface must have interface as name with Impl as suffix.")
	void classImplementingInterfaceNamingTest() {
		classes()
				.that(EngagementArchPredicates.implementsSingleInterface)
				.should(EngagementArchConditions.classNameEndsWithInterfaceNameWithImplSuffix)
				.because("class must be named as per implementing interface for easier identification")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Public Method must have JavaDoc ")
	void publicMethodHavingJavadocTest() {
		classes()
				.that().arePublic()
				.should(EngagementArchConditions.publicMethodMustHaveJavaDoc)
				.because("having JavaDoc makes code more readable")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Class must have JavaDoc ")
	void classHavingJavadocTest() {
		classes()
				.should(EngagementArchConditions.classShouldHaveJavaDoc)
				.because("having JavaDoc makes code more readable")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Package name must follow edu.pk.demo.archunit.*")
	void packageNamingConventionTest() {
		classes()
				.should(EngagementArchConditions.packageNamesShouldFollowConvention)
				.because("we follow a standard package structure")
				.check(allClasses);
	}
	
	@Test
	@DisplayName("Method should not contains object creation expression with new keyword")
	void methodHavingObjectCreationExprTest() {
		classes()
				.should(EngagementArchConditions.methodHavingObjectCreationWithNewKeyword)
				.because("creating object with \"new\" keyword reduces the testability of code")
				.check(allClasses);
	}
	
}
