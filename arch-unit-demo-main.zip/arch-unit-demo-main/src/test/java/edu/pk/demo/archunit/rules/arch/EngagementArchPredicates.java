package edu.pk.demo.archunit.rules.arch;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.domain.JavaType;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: prajena Date: 30/07/24 Time: 11:05pm
 */
public class EngagementArchPredicates {
	
	public static final DescribedPredicate<JavaClass> implementsSingleInterface =
			new DescribedPredicate<JavaClass>("implementing single interface") {
				@Override
				public boolean test(JavaClass input) {
					if (!input.isInterface()) {
						final List<JavaType> interfaces = new ArrayList<>(input.getInterfaces());
						return interfaces.size() == 1;
					}
					return false;
				}
			};
}
