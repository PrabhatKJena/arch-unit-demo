ArchUnit User Guide
https://www.archunit.org/userguide/html/000_Index.html